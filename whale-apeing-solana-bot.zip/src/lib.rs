// Rust smart contract source
