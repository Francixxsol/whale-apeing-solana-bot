# Whale Apeing Solana Bot

A Solana trading bot with referral tracking.
